import React from "react";
import SideBar from "./components/SideBar";
import "./components/SideBar.css";
function App() {
  return (
    <>
      <div className="main-container">
        <SideBar />
      </div>
    </>
  )
}

export default App;
